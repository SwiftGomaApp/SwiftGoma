enum ConnectivityStatus { online, offline }
