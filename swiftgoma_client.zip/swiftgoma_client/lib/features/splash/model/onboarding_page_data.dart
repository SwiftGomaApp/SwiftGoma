class OnboardingPageData {
  const OnboardingPageData({
    required this.imagePath,
    required this.title,
    required this.description,
  });

  final String imagePath;
  final String title;
  final String description;

  static const List<OnboardingPageData> pages = [
    OnboardingPageData(
      imagePath: 'assets/images/onboarding_1.png',
      title: 'Create a prototype in just a few minutes',
      description:
          'Enjoy these pre-made components and worry only about creating the best product ever.',
    ),
    OnboardingPageData(
      imagePath: 'assets/images/onboarding_2.png',
      title: 'Fast delivery right to your door',
      description:
          'Order from your favorite stores and track your delivery in real time, every step of the way.',
    ),
    OnboardingPageData(
      imagePath: 'assets/images/onboarding_3.png',
      title: 'Pay safely and easily',
      description:
          'Secure payments with the methods you already use and love. No hidden fees, ever.',
    ),
  ];
}